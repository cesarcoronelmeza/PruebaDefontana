USE Prueba 
GO 
---------------------------------------------------------------
/*0 - Consulta Full Ventas Detalle*/
---------------------------------------------------------------
SELECT 
V.ID_Venta, 
V.Fecha, 
V.ID_Local, 
L.Nombre LocalNombre , 
L.Direccion, 
V.Total, 

VD.ID_Producto,
P.Nombre ProductoNombre ,
m.Nombre MarcaNombre,

p.Costo_Unitario,
VD.Precio_Unitario, 
VD.Cantidad, 
VD.TotalLinea 
FROM [Venta] V
INNER JOIN [VentaDetalle] VD ON VD.ID_Venta = V.ID_Venta
INNER JOIN [Local] L ON L.ID_Local = V.ID_Local
INNER JOIN [Producto] P ON P.ID_Producto = VD.ID_Producto
INNER JOIN [Marca] M ON M.ID_Marca = P.ID_Marca
WHERE 
V.Fecha >= DATEADD(DAY,-30, GETDATE()) 


---------------------------------------------------------------
/*1 •	El total de ventas de los últimos 30 días (monto total y cantidad total de ventas).*/
---------------------------------------------------------------
SELECT
'Ventas total'  ReporteNombre,
SUM(VD.TotalLinea) MontoTotal ,
SUM(VD.Cantidad) CantidadTotal
FROM [Venta] V
INNER JOIN [VentaDetalle] VD ON VD.ID_Venta = V.ID_Venta
WHERE 
V.Fecha >= DATEADD(DAY,-30, GETDATE()) 

---------------------------------------------------------------
/*2 • El día y hora en que se realizó la venta con el monto más alto (y cuál es aquel monto).*/
---------------------------------------------------------------

SELECT
TOP 1
'Ventas más alta'  ReporteNombre,
CONVERT(DATE,V.Fecha) Día,
DATEPART(HOUR,V.FECHA) Hora,
V.ID_Venta,
V.Total
FROM [Venta] V
WHERE 
V.Fecha >= DATEADD(DAY,-30, GETDATE())
ORDER BY Total DESC 

---------------------------------------------------------------
/*3 •	Indicar cuál es el producto con mayor monto total de ventas.*/
---------------------------------------------------------------

SELECT 
TOP 1 
'Producto mayor venta'  ReporteNombre,
P.ID_Producto,
P.Nombre ProductoNombre,
SUM(VD.TotalLinea) MontoTotal
FROM [Venta] V
INNER JOIN [VentaDetalle] VD ON VD.ID_Venta = V.ID_Venta
INNER JOIN [Producto] P ON P.ID_Producto = VD.ID_Producto
WHERE 
V.Fecha >= DATEADD(DAY,-30, GETDATE())
GROUP BY 
P.ID_Producto,
P.Nombre
ORDER BY SUM(VD.TotalLinea) DESC;

---------------------------------------------------------------
/*4 •	Indicar el local con mayor monto de ventas.*/
---------------------------------------------------------------
SELECT 
TOP 1 
'Local mayor venta'  ReporteNombre,
V.ID_Local,
L.Nombre LocalNombre,
SUM(V.Total) MontoTotal
FROM [Venta] V
INNER JOIN [Local] L ON L.ID_Local = V.ID_Local
WHERE 
V.Fecha >= DATEADD(DAY,-30, GETDATE())
GROUP BY 
V.ID_Local,
L.Nombre
ORDER BY SUM(V.Total) DESC;

---------------------------------------------------------------
/*5 •	¿Cuál es la marca con mayor margen de ganancias.*/
---------------------------------------------------------------
SELECT
TOP 1
'Marca mayor margen'  ReporteNombre,
P.ID_Marca,
M.Nombre MarcaNombre,
SUM((VD.Cantidad * (VD.Precio_Unitario - P.Costo_Unitario))) MargenTotal
FROM [Venta] V
INNER JOIN [VentaDetalle] VD ON VD.ID_Venta = V.ID_Venta
INNER JOIN [Producto] P ON P.ID_Producto = VD.ID_Producto
INNER JOIN [Marca] M ON M.ID_Marca = P.ID_Marca
WHERE
V.Fecha >= DATEADD(DAY,-30, GETDATE()) 
GROUP BY 
P.ID_Marca,
M.Nombre
ORDER BY SUM((VD.Cantidad * (VD.Precio_Unitario - P.Costo_Unitario))) DESC;

---------------------------------------------------------------
/*6 •	¿Cómo obtendrías cuál es el producto que más se vende en cada local?.*/
---------------------------------------------------------------
SELECT
T2.LocalNombre,
T2.ProductoNombre,
T2.MaxMontoTotal 
FROM (
SELECT
T1.LocalNombre,
ROW_NUMBER() OVER(PARTITION BY T1.ID_Local ORDER BY T1.LocalNombre ASC , T1.MontoTotal DESC) AS "RowNumber", 
T1.ProductoNombre,
T1.MontoTotal,
MAX(T1.MontoTotal) OVER(PARTITION BY T1.ID_Local) AS MaxMontoTotal 
from (
SELECT 
V.ID_Local,
L.Nombre LocalNombre,
VD.ID_Producto,
P.Nombre ProductoNombre,
SUM(VD.TotalLinea) MontoTotal
FROM [Venta] V
INNER JOIN [VentaDetalle] VD ON VD.ID_Venta = V.ID_Venta
INNER JOIN [Producto] P ON P.ID_Producto = VD.ID_Producto
INNER JOIN [Local] L ON L.ID_Local = V.ID_Local
WHERE 
V.Fecha >= DATEADD(DAY,-30, GETDATE())
GROUP BY 
V.ID_Local,
L.Nombre,
VD.ID_Producto,
P.Nombre ) T1 
) T2
WHERE
T2.RowNumber = 1 
ORDER BY T2.LocalNombre ASC, T2.MaxMontoTotal DESC