﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleAppPrueba.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using ConsoleAppPrueba.DTO;
using System.Threading;
using System.Security.Cryptography.X509Certificates;

namespace ConsoleAppPrueba.Service;

public class VentasService
{
    private PruebaContext _dbContext;
    public VentasService(PruebaContext context)
    {
        _dbContext = context;
    }

    public void DisplayVentasQuestions()
    {
        Console.WriteLine("***************************************************************************************************");
        Console.WriteLine("***************************************************************************************************");
        Console.WriteLine("Prueba Defontana ");
        Console.WriteLine("***************************************************************************************************");
        Console.WriteLine("");
        //0 •   Consultar todas las ventas de los últimos 30 días
        var dtVentaList = SelectDataVentas(30);

        //----------------------------------------------------------------------------------------------------------------------
        //1 •	El total de ventas de los últimos 30 días(monto total y cantidad total de ventas).
        Console.WriteLine("** 1 •  P: El total de ventas de los últimos 30 días(monto total y cantidad total de ventas.");

        (double SumQty, double SumVta) resTotal30 = dtVentaList.Aggregate((SumQty: 0.0, SumVta: 0.0), (s, a) => (s.SumQty + a.Cantidad, s.SumVta + a.TotalLinea));

        Console.WriteLine("**     R: Ventas total | Monto total: " + String.Format("{0:C}", resTotal30.SumVta) + " , Cantidad Total: " + String.Format("{0:#,0.00}", resTotal30.SumQty));
        Console.WriteLine("");

        //----------------------------------------------------------------------------------------------------------------------
        //2 •	El día y hora en que se realizó la venta con el monto más alto (y cuál es aquel monto).
        Console.WriteLine("** 2 •  P: El día y hora en que se realizó la venta con el monto más alto (y cuál es aquel monto).");

        var resVentaAlta = (from venta in dtVentaList
                             orderby venta.TotalVenta descending
                             select venta).FirstOrDefault();

        Console.WriteLine("**     R: Venta más alta | Día: " + resVentaAlta.FechaVenta.ToShortDateString() + " , Hora: " + resVentaAlta.FechaVenta.ToShortTimeString() + " , Monto: " + String.Format("{0:C}", resVentaAlta.TotalVenta));
        Console.WriteLine("");

        //----------------------------------------------------------------------------------------------------------------------
        //3 •	Indicar cuál es el producto con mayor monto total de ventas.
        Console.WriteLine("** 3 •  P: Indicar cuál es el producto con mayor monto total de ventas.");

        var resProducto = dtVentaList
                        .Select(x =>
                            new {
                                IdProducto = x.IdProducto,
                                ProductoNombre = x.ProductoNombre,
                                VentaLinea = x.TotalLinea 
                            }
                         )
                         .GroupBy(s => new { s.IdProducto, s.ProductoNombre }) 
                         .Select(g =>
                                new {
                                    IdProducto = g.Key.IdProducto,
                                    ProductoNombre = g.Key.ProductoNombre, 
                                    SumVenta = g.Sum(x => Math.Round(Convert.ToDecimal(x.VentaLinea), 2)) 
                                }
                         )
                         .OrderByDescending(x => x.SumVenta)
                         .FirstOrDefault();

        Console.WriteLine("**     R: Producto mayor venta | IdProducto: " + resProducto.IdProducto + " , Producto Nombre: " + resProducto.ProductoNombre+ " , Monto Venta: " + String.Format("{0:C}", resProducto.SumVenta));
        Console.WriteLine("");


        //----------------------------------------------------------------------------------------------------------------------
        //4 •	Indicar el local con mayor monto de ventas.
        Console.WriteLine("** 4 •  P: Indicar el local con mayor monto de ventas.");

        var resLocal = dtVentaList
                        .Select(x =>
                            new {
                                IdLocal = x.IdLocal,
                                LocalNombre = x.LocalNombre,
                                VentaLinea = x.TotalLinea
                            }
                         )
                         .GroupBy(s => new { s.IdLocal, s.LocalNombre })
                         .Select(g =>
                                new {
                                    IdLocal = g.Key.IdLocal,
                                    LocalNombre = g.Key.LocalNombre,
                                    SumVenta = g.Sum(x => Math.Round(Convert.ToDecimal(x.VentaLinea), 2))
                                }
                         )
                         .OrderByDescending(x => x.SumVenta)
                         .FirstOrDefault();

        Console.WriteLine("**     R: Local mayor venta | IdLocal: " + resLocal.IdLocal + " , Local Nombre: " + resLocal.LocalNombre + " , Monto Venta: " + String.Format("{0:C}", resLocal.SumVenta));
        Console.WriteLine("");


        //----------------------------------------------------------------------------------------------------------------------
        //5 •	¿Cuál es la marca con mayor margen de ganancias?.
        Console.WriteLine("** 5 •  P: ¿Cuál es la marca con mayor margen de ganancias?.");

        var resMarca = dtVentaList
                        .Select(x =>
                            new {
                                IdMarca = x.IdMarca,
                                MarcaNombre = x.MarcaNombre,
                                MargenLinea = x.MargenLinea
                            }
                         )
                         .GroupBy(s => new { s.IdMarca, s.MarcaNombre })
                         .Select(g =>
                                new {
                                    IdMarca = g.Key.IdMarca,
                                    MarcaNombre = g.Key.MarcaNombre,
                                    SumMargen = g.Sum(x => Math.Round(Convert.ToDecimal(x.MargenLinea), 2))
                                }
                         )
                         .OrderByDescending(x => x.SumMargen)
                         .FirstOrDefault();

        Console.WriteLine("**     R: Marca mayor margen | IdMarca: " + resMarca.IdMarca + " , Marca Nombre: " + resMarca.MarcaNombre + " , Monto Margen: " + String.Format("{0:C}", resMarca.SumMargen));
        Console.WriteLine("");


        //----------------------------------------------------------------------------------------------------------------------
        //6 •	¿Cómo obtendrías cuál es el producto que más se vende en cada local?
        Console.WriteLine("** 6 •  P: ¿Cómo obtendrías cuál es el producto que más se vende en cada local?.");
        int i = 1;
        string LocalNombre = "Local Nombre", ProductoNombre = "Producto Nombre", SumVentaTotal = "Venta Total";

        var resLocalProducto = dtVentaList
                        .Select(x =>
                            new
                            {
                                IdLocal = x.IdLocal,
                                LocalNombre = x.LocalNombre,
                                IdProducto = x.IdProducto,
                                ProductoNombre = x.ProductoNombre,
                                VentaLinea = x.TotalLinea
                            }
                         )
                         .GroupBy(s => new { s.IdLocal, s.LocalNombre, s.IdProducto, s.ProductoNombre })
                         .Select(g =>
                                new
                                {
                                    IdLocal = g.Key.IdLocal,
                                    LocalNombre = g.Key.LocalNombre,
                                    IdProducto = g.Key.IdProducto,
                                    ProductoNombre = g.Key.ProductoNombre,
                                    SumVentaTotal = g.Sum(x => Math.Round(Convert.ToDecimal(x.VentaLinea), 2))
                                }
                         )
                         .OrderBy(x => x.LocalNombre)
                         .ThenByDescending(x => x.SumVentaTotal)
                         .GroupBy(x => x.LocalNombre)
                         .SelectMany(x => x.Select((j,i) => new { j.LocalNombre, j.ProductoNombre, j.SumVentaTotal, row = i+1 }))
                         .Where(n => n.row == 1)
                         .OrderBy(x => x.LocalNombre)
                         .ToList();
         
        Console.WriteLine("**     R: Reporte Producto más Vendido por local" );
        Console.WriteLine("**");
         
        Console.WriteLine("          #  " + LocalNombre.PadRight(16) + " " + ProductoNombre.PadRight(20) + " " + SumVentaTotal.PadLeft(15));
        foreach (var obj in resLocalProducto) {
            Console.WriteLine("          "+ i.ToString().PadRight(2) + " " + obj.LocalNombre.PadRight(16) + " " + obj.ProductoNombre.PadRight(20) + " " + String.Format("{0:C}", obj.SumVentaTotal).PadLeft(15)) ;
            i++; 
        }


        Console.ReadLine();
    }

    public List<VentasDTO> SelectDataVentas(int DiasConsulta) {
        DateTime fechaFiltro = DateTime.Now.AddDays(-DiasConsulta);
        List<VentasDTO> listReturn = new List<VentasDTO>();

        var VentaList = (from venta in _dbContext.Venta
                         join ventadetalle in _dbContext.VentaDetalles on venta.IdVenta equals ventadetalle.IdVenta
                         join producto in _dbContext.Productos on ventadetalle.IdProducto equals producto.IdProducto
                         join local in _dbContext.Locals on venta.IdLocal equals local.IdLocal
                         join marca in _dbContext.Marcas on producto.IdMarca equals marca.IdMarca
                         where
                         venta.Fecha >= fechaFiltro

                         select new
                         {
                             IdVenta =venta.IdVenta,
                             FechaVenta = venta.Fecha,
                             IdLocal = venta.IdLocal,
                             LocalNombre = local.Nombre,
                             TotalVenta = venta.Total,

                             IdProducto = ventadetalle.IdProducto,
                             ProductoNombre = producto.Nombre,
                             IdMarca = producto.IdMarca,
                             MarcaNombre = marca.Nombre,

                             CostoUnitario = producto.CostoUnitario,
                             PrecioUnitario = ventadetalle.PrecioUnitario,
                             MargenUnitario = ventadetalle.PrecioUnitario - producto.CostoUnitario,
                             Cantidad = ventadetalle.Cantidad,
                             TotalLinea  = ventadetalle.TotalLinea,
                             MargenLinea = ((ventadetalle.PrecioUnitario - producto.CostoUnitario) * ventadetalle.Cantidad)

                         }).ToList();

        foreach (var obj in VentaList) {
            VentasDTO ventas = new VentasDTO() { 
            IdVenta = obj.IdVenta,
            FechaVenta = obj.FechaVenta,
            IdLocal = obj.IdLocal,
            LocalNombre= obj.LocalNombre,
            TotalVenta= obj.TotalVenta,
            IdProducto= obj.IdProducto,
            ProductoNombre= obj.ProductoNombre,
            IdMarca = obj.IdMarca,
            MarcaNombre= obj.MarcaNombre,
            CostoUnitario = obj.CostoUnitario,
            PrecioUnitario= obj.PrecioUnitario,
            MargenUnitario = obj.MargenUnitario,
            Cantidad= obj.Cantidad,
            TotalLinea= obj.TotalLinea,
            MargenLinea= obj.MargenLinea
            };

            listReturn.Add(ventas); 
        }
 
        return listReturn; 
    } 

}
