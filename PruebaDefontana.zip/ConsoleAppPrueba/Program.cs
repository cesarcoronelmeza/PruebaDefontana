﻿using ConsoleAppPrueba.Models;
using ConsoleAppPrueba.Service;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;

namespace ConsoleAppPrueba
{
    class Program
    {
        static void Main(string[] args)
        {
            var builder = new ConfigurationBuilder()
                     .SetBasePath(Directory.GetCurrentDirectory())
                     .AddJsonFile("appsettings.json", optional: false);

            IConfiguration config = builder.Build();
            var connectionString = config.GetConnectionString("CadenaSQL");

            var services = new ServiceCollection();
            services.AddSingleton<VentasService>();
            services.AddDbContext<PruebaContext>(options => options.UseSqlServer(connectionString));
            ServiceProvider serviceProvider = services.BuildServiceProvider();

            var _Service = serviceProvider.GetService<VentasService>();
            _Service.DisplayVentasQuestions();

        }
    }
}