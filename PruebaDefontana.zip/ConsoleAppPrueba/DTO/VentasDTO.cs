﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppPrueba.DTO;
public class VentasDTO
{
    public long IdVenta { get; set; }
    public DateTime FechaVenta { get; set; }  
    public long IdLocal { get; set; }
    public string LocalNombre { get; set; } = null!;
    public int TotalVenta { get; set; } 
    public long IdProducto { get; set; }
    public string ProductoNombre { get; set; } = null!;
    public long IdMarca { get; set; } 
    public string MarcaNombre { get; set; } = null!;

    public int CostoUnitario { get; set; }
    public int PrecioUnitario { get; set; }
    public int MargenUnitario { get; set; }
    public int Cantidad { get; set; }
    public int TotalLinea { get; set; }
    public int MargenLinea { get; set; }
}
